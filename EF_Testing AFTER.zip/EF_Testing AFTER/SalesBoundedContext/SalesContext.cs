﻿using System;
using System.Data;
using System.Data.Entity;
using DataLayer.Mapping;
using DomainClasses;

namespace DataLayer
{
  public interface ISalesContext:IContext
  {
    IDbSet<Customer> Customers { get;  }
    IDbSet<Order> Orders { get;  }
    IDbSet<LineItem> LineItems { get;  }
    IDbSet<Product> Products { get;  }
    IDbSet<Payment> Payments { get;  }
    IDbSet<Category> Categories { get;  }
    IDbSet<Promotion> Promotions { get;  }
  }

 public class SalesContext:  BaseContext<SalesContext>, ISalesContext
  {
    public IDbSet<Customer> Customers { get; set; }
    public IDbSet<Order> Orders { get; set; }
    public IDbSet<LineItem> LineItems { get; set; }
    public IDbSet<Product> Products { get; set; }
    public IDbSet<Payment> Payments { get; set; }
    public IDbSet<Category> Categories { get; set; }
    public IDbSet<Promotion> Promotions { get; set; }
    public void SetModified(object entity)
    {
      Entry(entity).State = EntityState.Modified;
    }

    public void SetAdd(object entity)
    {
      Entry(entity).State = EntityState.Added;
    }


    protected override void OnModelCreating(DbModelBuilder modelBuilder)
    {
      modelBuilder.Configurations.Add(new LineItemMap());
    }
  }
}
