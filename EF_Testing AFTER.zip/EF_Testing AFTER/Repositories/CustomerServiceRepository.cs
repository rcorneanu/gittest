﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using DataLayer;
using DataLayer.Interfaces;
using DomainClasses;

namespace CustomerService.Repositories.Disconnected
{
  public class CustomerRepository : ICustomerRepository
  {
    private readonly CustomerServiceContext _context;
    public CustomerRepository(IUnitOfWork uow)
    {
      _context = uow.Context as CustomerServiceContext;
    }

    public IQueryable<Customer> All
    {
      get { return _context.Customers; }
    }

    public List<Customer> AllCustomers
    {
      get { return _context.Customers.ToList(); }
    }
    public List<Customer> AllCustomersWhoHaveOrdered
    {
      get { return _context.Customers.Where(c=>c.Orders.Any()).ToList(); }
    }

    public IQueryable<Customer> AllIncluding(params Expression<Func<Customer, object>>[] includeProperties)
    {
      IQueryable<Customer> query = _context.Customers;
      foreach (var includeProperty in includeProperties)
      {
        query = query.Include(includeProperty);
      }
      return query;
    }

    public Customer Find(int id)
    {
      return _context.Customers.Find(id);
    }

    public void InsertOrUpdateGraph(Customer customerGraph)
    {
      if (customerGraph.State==ObjectState.State.Added)
      {
        _context.Customers.Add(customerGraph);
      }
      else
      {
        _context.Customers.Add(customerGraph);
        _context.ApplyStateChanges();
      }
    }

    public void InsertOrUpdate(Customer customer)
    {
      if (customer.Id == default(int)) // New entity
      {
        _context.Entry(customer).State = EntityState.Added;
      }
      else        // Existing entity
      {
        _context.Entry(customer).State = EntityState.Modified;
 
      }
    }

    public void Delete(int id)
    {
      var customer = _context.Customers.Find(id);
      _context.Customers.Remove(customer);
    }

    public void Dispose()
    {
      _context.Dispose();
    }

  }

}