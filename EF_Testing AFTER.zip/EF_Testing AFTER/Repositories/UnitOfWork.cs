﻿using System;
using DataLayer;

namespace CustomerService
{
  public class UnitOfWork : IUnitOfWork<CustomerServiceContext>
  {
    private readonly CustomerServiceContext _context;


    public UnitOfWork()
    {
      _context = new CustomerServiceContext();
    }

    public UnitOfWork(CustomerServiceContext context)
    {
      _context = context;
    }
    public int Save()
    {
      return _context.SaveChanges();
    }

    public CustomerServiceContext Context
    {
      get { return _context; }
    }

    public void Dispose()
    {
      _context.Dispose();
    }
  }
}
