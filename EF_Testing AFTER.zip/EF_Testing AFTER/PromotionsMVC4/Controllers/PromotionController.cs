﻿using System;
using System.Linq;
using System.Web.Mvc;
using DataLayer;
using DomainClasses;
using SalesPromotions.Repositories.Disconnected;

namespace PromotionsMVC4.Controllers
{
  public class PromotionController : Controller
  {


    private readonly SalesPromotionAccessor _promoAccessor;

    public PromotionController()
    {
      _promoAccessor = new SalesPromotionAccessor();
    }



    public ActionResult Index()
    {
      var promos = _promoAccessor.Repo.All.ToList();
      return View(promos);
    }



    public ActionResult Create()
    {
      return View();
    }

    [HttpPost]
    public ActionResult Create(Promotion promotion)
    {
      try
      {
        _promoAccessor.Repo.InsertOrUpdate(promotion);
        _promoAccessor.Save();
        return RedirectToAction("Index");
      }
      catch
      {
        return View();
      }
    }


    public ActionResult Edit(int id)
    {
      return View(_promoAccessor.Repo.Find(id));
    }

    [HttpPost]
    public ActionResult Edit(int id, Promotion promotion)
    {
      try
      {
        _promoAccessor.Repo.InsertOrUpdate(promotion);
        _promoAccessor.Save();

        return RedirectToAction("Index");
      }
      catch
      {
        return View();
      }
    }

    //
    // GET: /Promotion/Delete/5

    public ActionResult Delete(int id)
    {
      return View(_promoAccessor.Repo.Find(id));
    }

    //
    // POST: /Promotion/Delete/5

    [HttpPost]
    public ActionResult Delete(int id, FormCollection collection)
    {
      try
      {
        _promoAccessor.Repo.Delete(id);
        _promoAccessor.Save();
        return RedirectToAction("Index");
      }
      catch
      {
        return View();
      }
    }

    public ActionResult GetOrders(int id, DateTime startdate, String name)
    {
      ViewBag.PromoName = name;
      var orders = _promoAccessor.Repo.OrdersViaPromotion
        (new Promotion { PromotionId = id, StartDate = startdate });
      if (orders == null)
      {
        return RedirectToAction("Index");
      }
      return View(orders);
    }
  }
}