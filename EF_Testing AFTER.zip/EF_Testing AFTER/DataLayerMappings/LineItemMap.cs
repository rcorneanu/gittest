using System.Data.Entity.ModelConfiguration;
using DomainClasses;

namespace DataLayer.Mapping
{
	public class LineItemMap : EntityTypeConfiguration<LineItem>
	{
		public LineItemMap()
		{
      //not mapped to database
      Ignore(t => t.LineTotal);
		}
	}
}

