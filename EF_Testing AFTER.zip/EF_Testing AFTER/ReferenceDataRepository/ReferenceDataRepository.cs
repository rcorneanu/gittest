﻿
using System;
using System.Linq;
using DomainClasses;
using ObjectReferenceLibrary;


namespace ReferenceData
{
  //ref data is special and does not use IStateObject or IObjectInterface
  public class ReferenceDataRepository:IDisposable
  { 
    private readonly ReferencesContext _context;
    public ReferenceDataRepository()
    {
      _context = new ReferencesContext();
    }

    public IQueryable<ProductReference> Products
    {
      get { return _context.Products.AsNoTracking(); }
    }
    public IQueryable<CustomerReference> Customers
    {
      get { return _context.Customers.AsNoTracking(); }
    }

    public void Dispose()
    {
      _context.Dispose();
    }
  }
}
