﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DomainClasses;

namespace FakesForTesting
{
  class PromotionFakeDbSet:FakeDbSet<Promotion>
  {
    public override Promotion Find(params object[] keyValues)
    {
      var keyValue = (int)keyValues.FirstOrDefault();
      return this.SingleOrDefault(p => p.PromotionId == keyValue);
    }
  }

  class OrderFakeDbSet : FakeDbSet<Order>
  {
    public override Order Find(params object[] keyValues)
    {
      var keyValue = (int)keyValues.FirstOrDefault();
      return this.SingleOrDefault(o=>o.OrderId == keyValue);
    }
  }
}
