﻿using System;
using System.Data.Entity;
using DataLayer;
using DomainClasses;

namespace FakesForTesting
{
  public class FakeSalesContext:ISalesContext
  {
    public FakeSalesContext()
    {
        Orders= new OrderFakeDbSet();
    }
    public IDbSet<Customer> Customers { get; private set; }
    public IDbSet<Order> Orders { get; private set; }
    public IDbSet<LineItem> LineItems { get; private set; }
    public IDbSet<Product> Products { get; private set; }
    public IDbSet<Payment> Payments { get; private set; }
    public IDbSet<Category> Categories { get; private set; }
    public IDbSet<Promotion> Promotions { get; private set; }
    public int SaveChanges()
    {
      throw new NotImplementedException();
    }

    public void SetModified(object entity)
    {
      throw new NotImplementedException();
    }

    public void SetAdd(object entity)
    {
      throw new NotImplementedException();
    }

    public void Dispose()
    {
      
    }
  }
}
