﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using DataLayer;
using DataLayer.Interfaces;
using DomainClasses;

namespace SalesPromotions.Repositories.Disconnected
{
  public class SalesPromotionAccessor
  {
    private readonly UnitOfWork<SalesContext> _uow;
    private readonly SalesPromotionRepository _repo;
    public SalesPromotionAccessor()
    {
     _uow= new UnitOfWork<SalesContext>();
      _repo=new SalesPromotionRepository(_uow);
    }

    public SalesPromotionRepository Repo
    {
      get { return _repo; }
    }
    
    public void Save()
    {
      _uow.Save();
    }


  }

  public class SalesPromotionRepository : ISalesPromotionRepository
  {
    private readonly ISalesContext _context;
    public SalesPromotionRepository(IUnitOfWork uow)
    {
      _context = uow.Context as ISalesContext;
    }



    public IQueryable<Promotion> All
    {
      get { return _context.Promotions; }
    }

    public IQueryable<Promotion> AllIncluding(params Expression<Func<Promotion, object>>[] includeProperties)
    {
      IQueryable<Promotion> query = _context.Promotions;
      foreach (var includeProperty in includeProperties)
      {
        query = query.Include(includeProperty);
      }
      return query;
    }

    public Promotion Find(int id)
    {
      return _context.Promotions.Find(id);
    }

    public void InsertOrUpdate(Promotion promotion)
    {
      if (promotion.PromotionId == default(int)) // New entity
      {
        _context.SetAdd(promotion);
      }
      else        // Existing entity
      {
        _context.SetModified(promotion);

      }
    }

    public void Delete(int id)
    {
      var promotion = _context.Promotions.Find(id);
      _context.Promotions.Remove(promotion);
    }

    public List<Order> OrdersViaPromotion(Promotion promo)
    {
      if (promo.StartDate <= DateTime.Today)
      {
        return _context.Orders.Where(o => o.PromotionId == promo.PromotionId).ToList();
      }
      return null;
    }

    public Nullable<int> CountOfOrdersGenerated(int promotionId, DateTime promotionStartDate)
    {
      if (promotionStartDate <= DateTime.Today)
      {
        return _context.Orders.Count(o => o.PromotionId == promotionId);
      }
      return null;
    }

    public void Dispose()
    {

    }

  }

}