﻿using DataLayer;

namespace SalesPromotions
{
  public class UnitOfWork : IUnitOfWork<SalesContext>
  {

    private readonly SalesContext _context;


    public UnitOfWork()
    {
      _context = new SalesContext();
    }

    public UnitOfWork(SalesContext context)
    {
      _context = context;
    }
    public int Save()
    {
      return _context.SaveChanges();
    }

    public SalesContext Context
    {
      get { return _context; }
    }

    public void Dispose()
    {
      _context.Dispose();
    }
  }
}
