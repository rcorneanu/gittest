﻿using System.Data.Entity;
using DataLayer;
using DomainClasses;

namespace ObjectReferenceLibrary
{
  public class ReferencesContext: BaseContext<ReferencesContext>
  {
    public DbSet<ProductReference> Products { get; set; }
    public DbSet<CustomerReference> Customers { get; set; }
  }
}
