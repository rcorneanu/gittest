﻿using System;
using System.Data.Entity;
namespace DataLayer
{
  public interface IUnitOfWork:IDisposable 
  {
    int Save();
    IContext Context { get; }
  
  }
  
}