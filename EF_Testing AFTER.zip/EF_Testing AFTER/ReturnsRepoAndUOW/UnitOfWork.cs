﻿using DataLayer;

namespace Returns
{
  public class UnitOfWork : IUnitOfWork<ReturnsContext>
  {
    private readonly ReturnsContext _context;


    public UnitOfWork()
    {
      _context = new ReturnsContext();
    }

    public UnitOfWork(ReturnsContext context)
    {
      _context = context;
    }
    public int Save()
    {
      return _context.SaveChanges();
    }

    public ReturnsContext Context
    {
      get { return _context; }
    }

    public void Dispose()
    {
      _context.Dispose();
    }
  }
}
