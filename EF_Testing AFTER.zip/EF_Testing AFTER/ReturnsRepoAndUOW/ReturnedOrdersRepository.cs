﻿using System;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using DataLayer;
using DataLayer.Interfaces;
using DomainClasses;
using Returns;

namespace Returns.Repositories.Disconnected
{
  //this doesn't implement IEntityRepository because it has different logic
  public class ReturnedOrderRepository : IDisposable
  {
    private readonly IReturnsContext _context;
    public ReturnedOrderRepository(IUnitOfWork uow)
    {
      _context = uow.Context as IReturnsContext;
    }

    public IQueryable<Order> All
    {
      get { return _context.Returns.Select(r=>r.Order); }
    }

    public IQueryable<Order> AllIncluding(params Expression<Func<Order, object>>[] includeProperties)
    {
      IQueryable<Order> query = _context.Returns.Select(r => r.Order);
      foreach (var includeProperty in includeProperties)
      {
        query = query.Include(includeProperty);
      }
      return query;
    }

    public Order Find(int id)
    {
      return _context.Returns
        .Where(r => r.OrderId == id)
        .Select(r => r.Order)
        .SingleOrDefault();
    }

 
    public void UpdateOrInsertReturnForOrder(Return returnForOrder)
    {
      if (returnForOrder.ReturnId == default(int)) // New entity
      {
        _context.SetAdd(returnForOrder);
      }
      else        // Existing entity
      {
        _context.SetModified(returnForOrder);
 
      }
    }

    public void Delete(int id)
    {
      var returnForOrder = _context.Returns.Find(id);
      _context.Returns.Remove(returnForOrder);
    }

    public void Dispose()
    {
      _context.Dispose();
    }

   
  }

}