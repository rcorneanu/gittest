﻿using System;
using System.Linq;
using System.Linq.Expressions;
using DomainClasses;

namespace DataLayer.Interfaces
{
  public interface ICustomerRepository : IEntityRepository<Customer>
  {

  }
  public interface IAddressRepository : IEntityRepository<Address>
  {

  }

  public interface ISalesPromotionRepository : IEntityRepository<Promotion>
  {
  }

  public interface IProductRepository : IEntityRepository<Product>
  { }
  public interface IEntityRepository<T> : IDisposable
  {
    IQueryable<T> All { get; }
    IQueryable<T> AllIncluding(params Expression<Func<T, object>>[] includeProperties);
    T Find(int id);
    void InsertOrUpdate(T entity);
    void Delete(int id);
  }
}
