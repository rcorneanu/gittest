using System.Data;
using System.Data.Entity;
using DataLayer.Mapping;
using DomainClasses;


namespace DataLayer
{
  public interface ICustomerServiceContext:IContext
  {
    DbSet<Customer> Customers { get; set; }
  }

  public class CustomerServiceContext :  BaseContext<CustomerServiceContext>, ICustomerServiceContext
  {
    public DbSet<Customer> Customers { get; set; }

    protected override void OnModelCreating(DbModelBuilder modelBuilder)
    {
      modelBuilder.Configurations.Add(new LineItemMap());
      modelBuilder.Entity<Shipment>();
      modelBuilder.Ignore<Category>();
    }

    public void SetModified(object entity)
    {
      Entry(entity).State=EntityState.Modified;
    }

    public void SetAdd(object entity)
    {
      Entry(entity).State = EntityState.Added;
    }
  }
}

