using System.Data.Entity;
using DataLayer.Mapping;
using DomainClasses;
using System.Collections.Generic;
using System;

namespace CompanyDatabaseInitialization
{
  public class CompanyDatabase : DbContext
  {
    public DbSet<Customer> Customers { get; set; }
    public DbSet<Employee> Employees { get; set; }
    public DbSet<SalaryHistory> SalaryHistories { get; set; }
    public DbSet<Order> Orders { get; set; }
    public DbSet<LineItem> LineItems { get; set; }
    public DbSet<Product> Products { get; set; }
    public DbSet<Shipment> Shipments { get; set; }
    public DbSet<Shipper> Shippers { get; set; }
    public DbSet<Address> Addresses { get; set; }
    public DbSet<Payment> Payments { get; set; }
    public DbSet<Category> Categories { get; set; }
    public DbSet<Promotion> Promotions { get; set; }
    public DbSet<Return> Returns { get; set; }

    protected override void OnModelCreating(DbModelBuilder modelBuilder)
    {
      modelBuilder.Configurations.Add(new LineItemMap());

    }
  }
  public class DatabaseSeedingInitializer : DropCreateDatabaseAlways<CompanyDatabase>
  {
    protected override void Seed(CompanyDatabase context)
    {
      var bikeProduct = new Product
      {
        ProductNumber = "BK-R68R-44",
        Name="Bike Saturday",
        Category = new Category { Name = "Bikes" },
        Color = "Blue",
        ListPrice = 500M,
        ShippingWeight = 30M,
        SellStartDate = new System.DateTime(2011, 1, 1)
      };

      var cust = new Customer
      {
        FirstName = "Julie",
        LastName = "Lerman",
        Phone = "802 555 1212",
        EmailAddress = "julielerman@gmail.com",
        Addresses = new List<Address> { new Address { Street1 = "Main St", City = "Anytown" } },
        Title = "Ms.",
        CompanyName = "The Data Farm",
        Orders = new List<Order>
                         {
                           new Order
                           {
                             OrderDate = DateTime.Now,
                             DueDate = DateTime.Now.AddDays(7),
                             ModifiedDate = DateTime.Now,
                             LineItems = new List<LineItem>
                             {
                               new LineItem
                               {
                                 OrderQty = 1,
                                 Product=bikeProduct,
                                 UnitPrice = bikeProduct.ListPrice
                               }
                             }
                           }
                         }
      };
      context.Customers.Add(cust);
      context.Returns.Add(new Return
      {
        DateTime = DateTime.Now,
        Order = new Order
        {
          OrderDate = DateTime.Now,
          DueDate = DateTime.Now.AddDays(7),
          ModifiedDate = DateTime.Now,
          LineItems = new List<LineItem>
                             {
                               new LineItem
                               {
                                 OrderQty = 4,
                                 Product=bikeProduct,
                                 UnitPrice = bikeProduct.ListPrice
                               }
                             }
        }
      });
        
    }
  }
}

