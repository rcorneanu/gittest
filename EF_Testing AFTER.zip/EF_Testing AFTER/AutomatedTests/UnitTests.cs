﻿using System.Collections.Generic;
using FakesForTesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DomainClasses;
using System;
using SalesPromotions.Repositories.Disconnected;

namespace AutomatedTests
{
  [TestClass]
  public class UnitTests
  {

    //[TestMethod]
    //public void CustomerClassDoesNotAllowLastNameMoreThan40Chars()
    //{
    //  const string fiftyCharString = "12345678901234567890123456789012345678901234567890";
    //  try
    //  {
    //    new Customer { LastName = fiftyCharString };
    //    Assert.Fail("Expected Exception was not thrown");
    //  }
    //  catch (Exception ex)
    //  {
    //    Assert.AreEqual(ex.Message, "LastName cannot exceed 40 characters");
    //  }
    //}

    //[TestMethod]
    //public void CustomerClassAllowsLastNameUpTo40Chars()
    //{
    //  const string fortyCharString = "1234567890123456789012345678901234567890";
    //  var customer = new Customer { LastName = fortyCharString };
    //  Assert.IsTrue(customer.LastName == fortyCharString);
    //}





    [TestMethod]
    public void GetOrdersForPastPromotionsExecutesQuery()
    {
      var promo = new Promotion { StartDate = DateTime.Today.AddDays(-1) };
      using (var uow = new DataLayer.UnitOfWork<FakeSalesContext>())
      {
        using (var repo = new SalesPromotionRepository(uow))
        {
          Assert.IsInstanceOfType(repo.OrdersViaPromotion(promo),
            typeof(List<Order>));
        }
      }
    }

    [TestMethod]
    public void GetOrdersForFuturePromotionsSkipsQueryAndReturnsNull()
    {
      var promo = new Promotion { StartDate = DateTime.Today.AddDays(+1) };
      using (var uow = new DataLayer.UnitOfWork<FakeSalesContext>())
      {
        using (var repo = new SalesPromotionRepository(uow))
        {
          Assert.IsNull(repo.OrdersViaPromotion(promo));
        }
      }
    }


    [TestMethod]
    public void GetOrdersForPastPromotionsReturnsCorrectNumberOfOrders()
    {
      var promo = new Promotion { PromotionId = 1, StartDate = DateTime.Today.AddDays(-1) };
      using (var fakeCtx = new FakeSalesContext())
      {
        fakeCtx.Orders.Add(new Order { OrderId = 1, PromotionId = 1 });
        fakeCtx.Orders.Add(new Order { OrderId = 2, PromotionId = 1 });
        fakeCtx.Orders.Add(new Order { OrderId = 3, PromotionId = 2 });
        using (var uow = new DataLayer.UnitOfWork<FakeSalesContext>(fakeCtx))
        {
          using (var repo = new SalesPromotionRepository(uow))
          {
            Assert.AreEqual(2, repo.OrdersViaPromotion(promo).Count);
          }
        }
      }
    }

  }
}
